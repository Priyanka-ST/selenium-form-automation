package utils;

public class TestData {
	
	public static String firstName = "Priya";
    public static String lastName = "K";
    public static String email = "priya@gmail.com";
    public static String mobile = "9876543210";

}
